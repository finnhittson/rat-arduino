#define SECRET_SSID ""
#define SECRET_PASS ""
#define SECRET_OTA_URL "http://downloads.arduino.cc/misc/WiFi1010_blinkRBG.bin"
